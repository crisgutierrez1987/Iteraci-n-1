# Parking-CW
¡Proyecto simple que simula un pequeño estacionamiento usando ES6 Javascript y manipula LocalStorage!
